({
	displayDivOne: function (c, e, h) {
		h.displayDivOne_helper(c, e, h);
	},

	displayDivTwo: function (c, e, h) {
		h.displayDivTwo_helper(c, e, h);
	}
})