//
//  ViewController.swift
//  JS_Performance
//
//  Created by Chad Adams on 12/3/14.
//  Copyright (c) 2014 Chad Adams. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var webview: UIWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let bundle = NSBundle.mainBundle()
        let pathofhtml = bundle.pathForResource("index", ofType: "html")
        
        webview.loadRequest(NSURLRequest(URL: NSURL(fileURLWithPath: pathofhtml!)!))
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
