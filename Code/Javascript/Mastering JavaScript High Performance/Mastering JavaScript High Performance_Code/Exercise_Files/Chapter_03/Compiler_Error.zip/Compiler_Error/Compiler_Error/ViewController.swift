//
//  ViewController.swift
//  Compiler_Error
//
//  Created by Chad Adams on 9/28/14.
//  Copyright (c) 2014 Chad Adams. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Assign a name to a constant variable, (which cannot be changed).
    let authors_name : String = "Chad Adams";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Here we have an error, our compiler complains that we can't change the name of "authors_name"
        authors_name = "Chad R. Adams";
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

