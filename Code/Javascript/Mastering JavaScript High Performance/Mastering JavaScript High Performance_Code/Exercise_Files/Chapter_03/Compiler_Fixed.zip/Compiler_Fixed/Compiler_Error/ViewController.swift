//
//  ViewController.swift
//  Compiler_Error
//
//  Created by Chad Adams on 9/28/14.
//  Copyright (c) 2014 Chad Adams. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var authors_name : String = "Chad Adams";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        authors_name = "Chad R. Adams";
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

