declare module "@apex/Youtubesearch.search" {
  export function search(param: {searchstr: any}): Promise<any>;
}
