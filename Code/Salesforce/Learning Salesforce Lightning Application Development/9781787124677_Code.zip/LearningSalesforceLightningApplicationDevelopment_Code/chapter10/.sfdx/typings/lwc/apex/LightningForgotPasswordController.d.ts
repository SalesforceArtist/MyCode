declare module "@apex/LightningForgotPasswordController.forgotPassword" {
  export function forgotPassword(param: {username: any, checkEmailUrl: any}): Promise<any>;
}
declare module "@apex/LightningForgotPasswordController.setExperienceId" {
  export function setExperienceId(param: {expId: any}): Promise<any>;
}
