({
    handleClick : function(component, event, helper) {
      helper.setSearchTerm(component, event);
    }
})