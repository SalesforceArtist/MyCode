({
    helperMethod : function(component, event) {
          console.log('hello');
    }
})
