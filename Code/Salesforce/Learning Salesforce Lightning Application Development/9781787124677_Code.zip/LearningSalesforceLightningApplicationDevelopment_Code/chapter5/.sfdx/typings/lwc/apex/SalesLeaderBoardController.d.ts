declare module "@apex/SalesLeaderBoardController.getSLDashboardData" {
  export function getSLDashboardData(): Promise<any>;
}
declare module "@apex/SalesLeaderBoardController.getlstopportunities" {
  export function getlstopportunities(param: {ownerId: any}): Promise<any>;
}
