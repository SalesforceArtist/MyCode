declare module "@apex/ContactController.getServerContacts" {
  export function getServerContacts(): Promise<any>;
}
