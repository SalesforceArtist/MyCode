embedded_svc.snippetSettingsFile.extraPrechatFormDetails = [{
  "label": "Logged In User Id",
  "transcriptFields": ["Logged_In_User_Id__c"],
}];