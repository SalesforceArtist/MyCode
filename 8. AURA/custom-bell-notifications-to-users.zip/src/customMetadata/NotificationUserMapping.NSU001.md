<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>NSU001</label>
    <protected>false</protected>
    <values>
        <field>Module__c</field>
        <value xsi:type="xsd:string">Apex Failure</value>
    </values>
    <values>
        <field>Name__c</field>
        <value xsi:type="xsd:string">System_Admins</value>
    </values>
    <values>
        <field>Type__c</field>
        <value xsi:type="xsd:string">Group</value>
    </values>
</CustomMetadata>
